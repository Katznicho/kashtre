<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\Business;
use App\Models\Branch;
use App\Models\ServicePoint;
use App\Models\User;

class ServiceCharge extends Model
{
    use HasFactory;

    protected $fillable = [
        'entity_type',
        'entity_id',
        'amount',
        'upper_bound',
        'lower_bound',
        'type',
        'is_active',
        'business_id',
        'created_by',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'upper_bound' => 'decimal:2',
        'lower_bound' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    /**
     * Validation rules for the model.
     */
    public static $rules = [
        'entity_type' => 'required|in:business,branch,service_point',
        'entity_id' => 'required|integer',
        'amount' => 'required|numeric|min:0',
        'upper_bound' => 'nullable|numeric|min:0',
        'lower_bound' => 'nullable|numeric|min:0',
        'type' => 'required|in:fixed,percentage',
        'is_active' => 'boolean',
        'business_id' => 'required|integer|exists:businesses,id',
        'created_by' => 'required|integer|exists:users,id',
    ];

    /**
     * Custom validation messages.
     */
    public static $messages = [
        'entity_type.required' => 'Entity type is required.',
        'entity_type.in' => 'Entity type must be business, branch, or service_point.',
        'entity_id.required' => 'Entity ID is required.',
        'entity_id.integer' => 'Entity ID must be a valid integer.',
        'amount.required' => 'Amount is required.',
        'amount.numeric' => 'Amount must be a valid number.',
        'amount.min' => 'Amount must be greater than or equal to 0.',
        'upper_bound.numeric' => 'Upper bound must be a valid number.',
        'upper_bound.min' => 'Upper bound must be greater than or equal to 0.',
        'lower_bound.numeric' => 'Lower bound must be a valid number.',
        'lower_bound.min' => 'Lower bound must be greater than or equal to 0.',
        'type.required' => 'Type is required.',
        'type.in' => 'Type must be either fixed or percentage.',
        'business_id.required' => 'Business ID is required.',
        'business_id.integer' => 'Business ID must be a valid integer.',
        'business_id.exists' => 'Selected business does not exist.',
        'created_by.required' => 'Created by user is required.',
        'created_by.integer' => 'Created by user ID must be a valid integer.',
        'created_by.exists' => 'Selected user does not exist.',
    ];

    /**
     * Boot method to add model events.
     */
    protected static function booted()
    {
        static::saving(function ($serviceCharge) {
            // Validate bounds relationship
            if ($serviceCharge->upper_bound !== null && $serviceCharge->lower_bound !== null) {
                if ($serviceCharge->upper_bound <= $serviceCharge->lower_bound) {
                    throw new \InvalidArgumentException('Upper bound must be greater than lower bound.');
                }
            }
            
            // Validate percentage limits
            if ($serviceCharge->type === 'percentage' && $serviceCharge->amount > 100) {
                throw new \InvalidArgumentException('Percentage amount cannot exceed 100%.');
            }
        });
    }

    /**
     * Get the business that owns the service charge.
     */
    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    /**
     * Get the user who created the service charge.
     */
    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Get the entity that this service charge applies to.
     */
    public function entity()
    {
        return $this->morphTo();
    }

    /**
     * Scope to filter by active service charges.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope to filter by business.
     */
    public function scopeForBusiness($query, $businessId)
    {
        return $query->where('business_id', $businessId);
    }

    /**
     * Scope to filter by entity type.
     */
    public function scopeForEntityType($query, $entityType)
    {
        return $query->where('entity_type', $entityType);
    }

    /**
     * Get the formatted amount with type.
     */
    public function getFormattedAmountAttribute(): string
    {
        if ($this->type === 'percentage') {
            return $this->amount . '%';
        }
        
        return 'UGX ' . number_format($this->amount, 2);
    }

    /**
     * Get the entity name.
     */
    public function getEntityNameAttribute(): string
    {
        try {
            switch ($this->entity_type) {
                case 'business':
                    return Business::find($this->entity_id)?->name ?? 'Unknown Business';
                case 'branch':
                    return Branch::find($this->entity_id)?->name ?? 'Unknown Branch';
                case 'service_point':
                    return ServicePoint::find($this->entity_id)?->name ?? 'Unknown Service Point';
                
                default:
                    return 'Unknown Entity';
            }
        } catch (\Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }
}
