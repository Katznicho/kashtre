<div>
    <!-- Filament Table -->
    {{ $this->table }}
</div>
