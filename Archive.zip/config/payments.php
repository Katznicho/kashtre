<?php

return [
    'yo_username' => env('YO_PAYMENTS_USERNAME'),
    'yo_password' => env('YO_PAYMENTS_PASSWORD'),
];

